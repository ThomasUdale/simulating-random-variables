use extendr_api::prelude::*;

use rand::{distributions::Distribution, rngs::ThreadRng, thread_rng, distributions::WeightedIndex};
use statrs::distribution::{Normal, Uniform,Exp,DiscreteUniform, Poisson};


#[extendr]
fn cts_smc_rust(ss: i32, target_time: f64) -> Vec<f64> {
  let ss: usize = ss as usize;

  let mut rng = thread_rng();

  let mut samples: Vec<f64> = vec![0.0;ss];
  let mut current_sample_time: Vec<f64> = vec![0.0;ss];
  let mut weights: Vec<f64> = vec![0.0f64;ss];
  let mut final_sample: Vec<f64> = vec![0.0f64;ss];

  let mut t: f64 = 0.0;

  let k_plus: Exp = Exp::new((ss as f64)*(5.0/8.0)).unwrap();
  let k_minus: Exp = Exp::new((ss as f64)*0.5).unwrap();
  let uniform_sample = DiscreteUniform::new(0,(ss-1).try_into().unwrap()).unwrap();
  let std = Normal::new(0.0, 1.0).unwrap();
  let u = Uniform::new(0.0,1.0).unwrap();

  let mut test_x = [0usize;2];
  while t < target_time {
    let e_plus = k_plus.sample(&mut rng);
    let e_minus = k_minus.sample(&mut rng);
    let new_t = (t + e_plus.min(e_minus)).min(target_time);
    test_x[0] = uniform_sample.sample(&mut rng)  as usize;
    samples[test_x[0]] = std.sample(&mut rng)*(new_t-current_sample_time[test_x[0]]).powf(0.5) + samples[test_x[0]];
    current_sample_time[test_x[0]] = new_t;
    let phi = 0.5*((samples[test_x[0]]-std::f64::consts::PI).sin().powf(2.0) + (samples[test_x[0]]-std::f64::consts::PI).cos());

    if e_plus < e_minus {
      if u.sample(&mut rng) < (phi.max(0.0)/(5.0/8.0)) {
        test_x[1] = uniform_sample.sample(&mut rng)  as usize;
        if test_x[0]!=test_x[1] {
          samples[test_x[1]] = std.sample(&mut rng)*(new_t-current_sample_time[test_x[1]]).powf(0.5) + samples[test_x[1]];
          current_sample_time[test_x[1]] = new_t;
          samples[test_x[0]] =   samples[test_x[1]];
        }
      }
    } else {
      if u.sample(&mut rng) < -phi.min(0.0)/(0.5) {
        test_x[1] = uniform_sample.sample(&mut rng)  as usize;
        if test_x[0]!=test_x[1] {
          samples[test_x[1]] = std.sample(&mut rng)*(new_t-current_sample_time[test_x[1]]).powf(0.5) + samples[test_x[1]];
          current_sample_time[test_x[1]] = new_t;
          samples[test_x[1]] =   samples[test_x[0]];
        }
      }
    }

    t=new_t;
  }




  for idx in 0..ss {
    if current_sample_time[idx] < target_time {
      samples[idx] = std.sample(&mut rng)*(target_time-current_sample_time[idx]).powf(0.5) + samples[idx];
    }
    weights[idx] = (-1.0-(samples[idx]-std::f64::consts::PI).cos()).exp()
  }



  let dist = WeightedIndex::new(&weights).unwrap();

  for idx in 0..ss {
    final_sample[idx] = samples[dist.sample(&mut rng) as usize];
  }

  final_sample
}

fn brownian_bridge(rng: &mut ThreadRng,x:&f64,y:&f64,s:&f64,t:&f64,times:&Vec<f64>) -> Vec<f64> {
  let std_n = Normal::new(0.0, 1.0).unwrap();
  let mut bm: Vec<f64> = Vec::new();
  for tid in 0..(times.len()+1) {
    if tid==0{
      bm.push(std_n.sample(rng)*(times[tid]-s).powf(0.5));
    } else if tid==times.len() {
      bm.push(std_n.sample(rng)*(t-times[tid-1]).powf(0.5) + bm[tid-1]);
    } else {
      bm.push(std_n.sample(rng)*(times[tid]-times[tid-1]).powf(0.5) + bm[tid-1]);
    }
  }

  for tid in 0..times.len() {
    bm[tid] = bm[tid] - (times[tid]/t)*bm[times.len()] + (1.0-(times[tid]/t))*x + (times[tid]/t)*y;
  }
  bm[0..times.len()].to_vec()
}

fn bbs(rng: &mut ThreadRng,t:&Vec<f64>,path:&Vec<f64>,times:&Vec<f64>) -> Vec<f64> {
  let mut bb: Vec<f64> = Vec::new();
  let mut cur_skel: Vec<f64> = Vec::new();
  let mut cur_index: usize = 1;
  let mut cur_tid: usize = 0;
  while cur_index<t.len() && cur_tid<times.len() {
    if times[cur_tid]<t[cur_index]  {
      cur_skel.push(times[cur_tid]);
      cur_tid+=1;
    } else {
      if cur_skel.len()>0 {
        bb.extend(brownian_bridge(
        rng,
        &path[cur_index-1],
        &path[cur_index],
        &t[cur_index-1],
        &t[cur_index],
        &cur_skel
      ));
      }
      cur_skel = Vec::new();
      cur_index+=1;
    }
  }
  if cur_skel.len()>0 {
    bb.extend(brownian_bridge(
        rng,
        &path[cur_index-1],
        &path[cur_index],
        &t[cur_index-1],
        &t[cur_index],
        &cur_skel
      ));
  }
  bb
}


#[extendr]
fn path_smc_rust(n:i32,n_steps:i32,tt:f64) -> List {
  let mut paths: Vec<Vec<f64>> = Vec::new();
  let mut old_paths : Vec<Vec<f64>> = Vec::new();
  let mut old_times : Vec<Vec<f64>> = Vec::new();
  let mut times: Vec<Vec<f64>> = Vec::new();
  let mut weights: Vec<f64> = vec![1.0f64;n as usize];

  let mut rng = thread_rng();
  let std_n = Normal::new(0.0, 1.0).unwrap();
  let k = Poisson::new(tt*(9.0/8.0)).unwrap();
  let u = Uniform::new(0.0,1.0).unwrap();

  for _ in 0..n {
    times.push(vec![0.0f64,tt]);
    paths.push(vec![0.0f64,std_n.sample(&mut rng)*tt.powf(0.5)]);
  }

  for t_step in 0..n_steps {
    for p in 0..n as usize {
      let mut new_x = 0.0f64;
      for idx in 1..(times[p].len()) {
        new_x += std_n.sample(&mut rng)*(times[p][idx]-times[p][idx-1]).powf(0.5);
        paths[p][idx] += new_x;
        paths[p][idx] /= (2f64).powf(0.5);
      }
    }

    for p in 0..n as usize {
      let kp = k.sample(&mut rng);
      if (kp as usize)==0 {
        weights[p] = 1.0;
      } else {
        let mut skeleton_u: Vec<f64> = (0..(kp as usize)).map(|_| u.sample(&mut rng)*tt).collect::<Vec<f64>>();
        skeleton_u.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let bb = bbs(
          &mut rng,
          &times[p],
          &paths[p],
          &skeleton_u,
        );
        weights[p] = bb.iter().fold(1.0, |res,a| res * (9.0/8.0-0.5-0.5*((a-std::f64::consts::PI).sin().powf(2.0) + (a-std::f64::consts::PI).cos()))/(9.0/8.0));
        let mut update_id: usize = 0;
        let mut reference_id: usize = 1;
        while update_id<skeleton_u.len() {
          if skeleton_u[update_id]>times[p][reference_id] {
            reference_id +=1;
          } else {
            times[p].insert(reference_id,skeleton_u[update_id]);
            paths[p].insert(reference_id,bb[update_id]);
            update_id+=1;
          }
        }
      }
    }

    old_paths = paths.clone();
    old_times = times.clone();
    let dist = WeightedIndex::new(&weights).unwrap();
    for p in 0..n as usize {
      let new_id = dist.sample(&mut rng) as usize;
      times[p] = old_times[new_id].clone();
      paths[p] = old_paths[new_id].clone();
    }
  }
  paths.extend(times);
  paths.push(weights);
  List::from_values(paths)
}

// Macro to generate exports.
// This ensures exported functions are registered with R.
// See corresponding C code in `entrypoint.c`.
extendr_module! {
    mod cts_smc;
    fn cts_smc_rust;
    fn path_smc_rust;
}

